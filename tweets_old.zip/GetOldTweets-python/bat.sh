#!/bin/sh

cd /home/ec2-user/GetOldTweets-python
python Exporter.py --querysearch "patrick’s day" --since 2018-03-01 --until 2018-03-31 --lang en --output "result6.csv"
python Exporter.py --querysearch "#StPatricksDay2018" --since 2018-03-01 --until 2018-03-31 --lang en --output "result7.csv"
python Exporter.py --querysearch "#StPatricksDay" --since 2018-03-01 --until 2018-03-31 --lang en --output "result8.csv"
python Exporter.py --querysearch "#SaintPatrick" --since 2018-03-01 --until 2018-03-31 --lang en --output "result9.csv"
python Exporter.py --querysearch "#StPatricksDayParade" --since 2018-03-01 --until 2018-03-31 --lang en --output "result10.csv"
python Exporter.py --querysearch "#patricks" --since 2018-03-01 --until 2018-03-31 --lang en --output "result11.csv"
python Exporter.py --querysearch "#SaintPatricksDay2018" --since 2018-03-01 --until 2018-03-31 --lang en --output "result12.csv"
python Exporter.py --querysearch "#SaintPatricksWeekend" --since 2018-03-01 --until 2018-03-31 --lang en --output "result13.csv"
python Exporter.py --querysearch "@stpatricksfest" --since 2018-03-01 --until 2018-03-31 --lang en --output "result14.csv"
